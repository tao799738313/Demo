(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            docEl.style.fontSize = 100 * (clientWidth / 750) + 'px';
        };
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
$(function () {
    //tab
    function tab($selector){
        var $lis = $selector.find('li');
        $lis.on('click',function (){
            var $index = $(this).index();
            $(this).addClass('act').siblings().removeClass('act').end().parent().nextAll('div').eq($index).addClass('act').siblings('div').removeClass('act');
        });
    }
    $.each($('#tab'),function (){
        tab($(this));
    });

    // 获取验证码倒计时
    (function () {
        var flag = true;
        var now = 60;
        var timer = null;
        function numCountdown(ele) {
            if (flag === true) {
                flag = false;
                $(ele).addClass('disabled');
                $(ele).html('<i>60</i>s重新发送');
                timer = setInterval(function () {
                    if (now>1) {
                        now -= 1;
                        $(ele).html('<i>'+ now +'</i>s重新发送');
                    }
                }, 1000);
                setTimeout(function () {
                    $(ele).removeClass('disabled');
                    $(ele).html('获取验证码');
                    flag = true;
                    timer = null;
                },60000);
            } else {
                return false;
            }
        }

        $('.getCodeBtn').on('touchend', function () {
            numCountdown(this);
        });
    })();

    //显示遮罩层及弹窗
    function showMask(){
        $("#mask").css("height",$(document).height());
        $("#mask").css("width",$(document).width());
        $("#mask").show();
        $('#model').show();
        $('body').css('position','fixed');
    }
    //showMask();
    //隐藏遮罩层
    function hideMask(){
        $("#mask").hide();
        $('body').css('position','unset');
    }
});