(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            docEl.style.fontSize = 100 * (clientWidth / 750) + 'px';
        };
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
$(function () {
    var flag = 1;
    $('#starBtn').on('click',function(){
        console.log(1)
        if(!flag){
            for(var i=1; i<=8; i++){
                $('.egg_'+i).removeClass('move_'+i)
            }
        }else{
            game();
        }
        flag = 0;
    });
    function game(){
        var number =Math.floor(4*Math.random()+1);   
 
    for(i=1;i<=8;i++){ 
            $(".egg_"+i).addClass("move_"+i); 
        }; 
             
    setTimeout(function (){ 
        for(i=1;i<=8;i++){ 
        $(".egg_"+i).removeClass("move_"+i); 
        } 
    },2000);     
    setTimeout(function(){ 
        switch(number){ 
            case 1:$(".zjdl").children("span").addClass("diaL_one");break; 
            case 2:$(".zjdl").children("span").addClass("diaL_two");break; 
            case 3:$(".zjdl").children("span").addClass("diaL_three");break; 
            case 4:$(".zjdl").children("span").addClass("diaL_four");break; 
        } 
        $(".zjdl").removeClass("none").addClass("dila_Y"); 
                setTimeout(function (){ 
                switch(number){ 
                    case 1:$("#jianpin_one").show();break; 
                    case 2:$("#jianpin_two").show();break; 
                    case 3:$("#jianpin_three").show();break; 
                    case 4:$("#jianpin_kong").show();break; 
                } 
            },900); 
        },1100) 
     
    //取消动画 
    setTimeout(function (){ 
            $(".zjdl").addClass("none").removeClass("dila_Y");$(".zjdl").children("span").removeAttr('class');  
        },2500) 
             
    }

    //显示遮罩层及弹窗
    function showMask(){
        $("#mask").css("height",$(document).height());
        $("#mask").css("width",$(document).width());
        $("#mask").show();
        $('#model').show();
        $('body').css('position','fixed');
    }
    //showMask();
    //隐藏遮罩层
    function hideMask(){
        $("#mask").hide();
        $('body').css('position','unset');
    }
});