(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            docEl.style.fontSize = 100 * (clientWidth / 750) + 'px';
        };
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
$(function () {

    //弹窗确定按钮
    $('.close').on('click',function(){
        $(this).parent().hide();
        hideMask();
    });
    //首页我的奖品按钮
    $('.myGift').on('click',function(){
        $('.model_2').fadeIn();
        showMask();
    });
    //首页活动规则按钮
    $('#ruleBtn').on('click',function(){
        $('.model_4').fadeIn();
        showMask();
    })

    //扭蛋机灯光
    window.setInterval(function(){
        $('.light').addClass('change');
        window.setTimeout(function(){
            $('.light').removeClass('change');
        },500);
    },1000);
    //抽奖
    var flag = 1; //有抽奖次数
    $('#starBtn').on('click',function(){
        if(!flag){
            for(var i=1; i<=8; i++){
                $('.egg_'+i).removeClass('move_'+i)
            }
        }else{
            game();
        }
        flag = 0;
    });
    function game(){
        var number =Math.floor(4*Math.random()+1);   
        for(i=1;i<=8;i++){ 
            $(".egg_"+i).addClass("move_"+i); 
            $(".egg_"+i).children('span').addClass('zhuan');
        };  
        setTimeout(function (){ 
            for(i=1;i<=8;i++){ 
                $(".egg_"+i).removeClass("move_"+i); 
            } 
        },1500);     
        setTimeout(function(){ 
            switch(number){ 
                case 1:$(".zjdl").children("span").addClass("diaL_one");break; 
                case 2:$(".zjdl").children("span").addClass("diaL_two");break; 
                case 3:$(".zjdl").children("span").addClass("diaL_three");break; 
                case 4:$(".zjdl").children("span").addClass("diaL_four");break; 
        } 
        $('.result').addClass('goDown');
        $(".zjdl").removeClass("none").addClass("dila_Y"); 
                setTimeout(function (){ 
                switch(number){ 
                    case 1:$("#jianpin_one").show();break; 
                    case 2:$("#jianpin_two").show();break; 
                    case 3:$("#jianpin_three").show();break; 
                    case 4:$("#jianpin_kong").show();break; 
                } 
            },900); 
        },1100) 
     
        //取消动画 
        setTimeout(function (){ 
            $('.result').removeClass('goDown');
            $(".zjdl").children("span").removeAttr('class');  
        },2500) 
    }

    //显示遮罩层及弹窗
    function showMask(){
        $("#mask").css("height",$(document).height());
        $("#mask").css("width",$(document).width());
        $("#mask").show();
        $('#model').show();
        $('body').css('position','fixed');
    }
    //showMask();
    //隐藏遮罩层
    function hideMask(){
        $("#mask").hide();
        $('body').css('position','unset');
    }
});